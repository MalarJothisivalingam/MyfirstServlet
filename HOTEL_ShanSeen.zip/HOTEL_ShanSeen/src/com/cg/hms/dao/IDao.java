package com.cg.hms.dao;

import java.util.ArrayList;

import com.cg.hms.dto.HotelBean;
import com.cg.hms.dto.RegisterBean;



public interface IDao 
{

	public ArrayList<HotelBean> viewAllDetails();
	public RegisterBean addDetails(RegisterBean bean);
}
