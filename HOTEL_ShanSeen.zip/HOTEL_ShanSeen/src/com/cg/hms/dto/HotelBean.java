package com.cg.hms.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="hoteldetails")
public class HotelBean 
{
	@Id
	@Column
	private int id;
	@Column(name="name")
	private String hotelname;
	@Column(name="rating")
	private String hotelrating;
	@Column(name="rate")
	private int price;
	@Column(name="availablerooms")
	private int rooms;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getHotelname() {
		return hotelname;
	}
	public void setHotelname(String hotelname) {
		this.hotelname = hotelname;
	}
	public String getHotelrating() {
		return hotelrating;
	}
	public void setHotelrating(String hotelrating) {
		this.hotelrating = hotelrating;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getRooms() {
		return rooms;
	}
	public void setRooms(int rooms) {
		this.rooms = rooms;
	}
	@Override
	public String toString() {
		return "HotelBean [id=" + id + ", hotelname=" + hotelname
				+ ", hotelrating=" + hotelrating + ", price=" + price
				+ ", rooms=" + rooms + "]";
	}
	
	

}
